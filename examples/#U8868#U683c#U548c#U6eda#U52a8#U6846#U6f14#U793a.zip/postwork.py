import pygrading as gg

from pygrading import Job
from pygrading.html import str2html


def postwork(job: Job) -> dict:
    """任务后处理函数

    用于汇总测试执行结果

    参数:
        job: 传入的当前任务对象

    返回值:
        返回值为空，后处理内容需要更新到job对象中
    """

    # 获取执行结果总分
    total_score = job.get_total_score()

    # 更新结果输出字段
    job.verdict("Accepted" if total_score == 100 else "Wrong Answer")
    job.score(total_score)
    job.comment("Mission Complete")

    # 渲染 HTML 模板页面（可选）
    # 被渲染的页面应位于 kernel/templates/html 目录下
    headers = ["#", "单点耗时(s)", "单点误差(%)", "分类结果", "通过情况"]
    results = [
        {"name": "第一测试点", "time": "22", "err": "12", "class": "Rabbit", "pass": "通过"},
        {"name": "第二测试点", "time": "29", "err": "9", "class": "Cat", "pass": "通过"},
        {"name": "第三测试点", "time": "18", "err": "17", "class": "Dog", "pass": "通过"},
        {"name": "第四测试点", "time": "24", "err": "13", "class": "Snake", "pass": "通过"},
    ]

    answer = str2html("""(1, 1061, 1059, 3)
                    CNML: 7.2.1 c8ada41
                    CNRT: 4.2.1 fa5e44c
                    CNML: 7.2.1 c8ada41
                    UID: 12
                    iteration: 1
                    Epoch 0, Iteration: 1, Loss: 191018290.0
                    style: 174005740.0, content:9533977.0, tv: 7478563.5
                    iteration: 2
                    Epoch 0, Iteration: 2, Loss: 150079890.0
                    style: 134786770.0, content:8507386.0, tv: 6785725.0
                    iteration: 3
                    Epoch 0, Iteration: 3, Loss: 139621730.0
                    style: 122878710.0, content:9465531.0, tv: 7277481.5
                    iteration: 4
                    Epoch 0, Iteration: 4, Loss: 149565760.0
                    style: 134663120.0, content:9628568.0, tv: 5274086.5
                    iteration: 5
                    Epoch 0, Iteration: 5, Loss: 140219840.0
                    style: 125711940.0, content:8222963.5, tv: 6284945.5
                    iteration: 6
                    Epoch 0, Iteration: 6, Loss: 140486050.0
                    style: 123590670.0, content:11174893.0, tv: 5720476.0
                    iteration: 7
                    Epoch 0, Iteration: 7, Loss: 137394800.0
                    style: 121974730.0, content:8706368.0, tv: 6713698.5
                    iteration: 8
                    Epoch 0, Iteration: 8, Loss: 134750190.0
                    style: 122794650.0, content:6377348.5, tv: 5578192.5
                    iteration: 9
                    Epoch 0, Iteration: 9, Loss: 123956104.0
                    style: 109682460.0, content:8676702.0, tv: 5596933.5
                    iteration: 10
                    Epoch 0, Iteration: 10, Loss: 128929160.0
                    style: 115169220.0, content:8458889.0, tv: 5301055.5
                    growth: -2484041.047619
                    TEST TRAINING SUCCESS.""")

    job.detail(gg.render_template("index.html", author="Charles Zhang", headers=headers, results=results, answer=answer))
